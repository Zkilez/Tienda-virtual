import React, { useState, useEffect, useRef, useCallback } from 'react';
import { FiX, FiArrowRight, FiShoppingCart, FiTrash2, FiRefreshCw, FiChevronUp, FiChevronDown } from 'react-icons/fi';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types';

const Chatbot = ({ 
  user = {}, 
  onClose = () => {},
  onMessageSent = () => {}
}) => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const chatRef = useRef(null);
  const inputRef = useRef(null);
  const scrollTimeoutRef = useRef(null);
  const isAutoScrolling = useRef(false);

  // Función para limpiar el historial del chat
  const clearChat = useCallback(() => {
    setMessages([{ 
      text: `¡Hola ${user?.name || 'amigo'}! 👋 Soy tu asistente de smartphones. ¿Qué modelo buscas hoy?`, 
      sender: 'bot',
      options: ['Ver opciones', 'Ayuda']
    }]);
  }, [user?.name]);

  // Funciones para desplazamiento
  const scrollToTop = useCallback(() => {
    if (chatRef.current) {
      isAutoScrolling.current = true;
      chatRef.current.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      setTimeout(() => {
        isAutoScrolling.current = false;
      }, 1000);
    }
  }, []);

  const scrollToBottom = useCallback((options = {}) => {
    if (chatRef.current) {
      const { behavior = 'smooth', force = false } = options;
      
      const { scrollTop, scrollHeight, clientHeight } = chatRef.current;
      const distanceFromBottom = scrollHeight - (scrollTop + clientHeight);
      
      if (force || distanceFromBottom < 200) {
        isAutoScrolling.current = true;
        chatRef.current.scrollTo({
          top: scrollHeight,
          behavior
        });
        setTimeout(() => {
          isAutoScrolling.current = false;
        }, 1000);
      }
    }
  }, []);

  // Manejar scroll para mostrar/ocultar botones
  const handleScroll = useCallback(() => {
    if (!chatRef.current || isAutoScrolling.current) return;
    
    const { scrollTop, scrollHeight, clientHeight } = chatRef.current;
    const isAtBottom = scrollHeight - (scrollTop + clientHeight) < 20;
    const isAtTop = scrollTop < 20;
    
    setShowScrollButtons(!isAtTop || !isAtBottom);
    
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }
    
    scrollTimeoutRef.current = setTimeout(() => {
      setShowScrollButtons(false);
    }, 3000);
  }, []);

  // Conexión con el backend Django
  const getBotResponse = useCallback(async (userMessage) => {
    setIsTyping(true);
    
    try {
      const response = await fetch('http://localhost:8000/chatbot/api/chat/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userMessage }),
      });

      const data = await response.json();

      // Formatea la respuesta para mostrar saltos de línea
      const formattedResponse = data.response.replace(/\n/g, '<br>');

      return {
        text: formattedResponse,
        options: ["Ver más opciones", "Ayuda"]
      };

    } catch (error) {
      console.error("Error al llamar al chatbot:", error);
      return {
        text: "⚠️ Error al conectar con el servidor. Intenta más tarde.",
        options: []
      };
    } finally {
      setIsTyping(false);
    }
  }, []);

  // Manejo del envío de mensajes
  const handleSendMessage = useCallback(async (e) => {
    e?.preventDefault();
    if (!message?.trim()) return;

    // Mensaje del usuario
    const userMessage = { text: message, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setMessage('');
    onMessageSent();

    // Respuesta del backend Django
    const botResponse = await getBotResponse(message);
    setMessages(prev => [...prev, { 
      text: botResponse.text, 
      sender: 'bot',
      options: botResponse.options,
      isHTML: true // Indica que el texto contiene HTML
    }]);

    scrollToBottom({ behavior: 'smooth', force: true });
  }, [message, getBotResponse, onMessageSent, scrollToBottom]);

  // Mensaje inicial
  useEffect(() => {
    setMessages([{ 
      text: `¡Hola ${user?.name || 'amigo'}! 👋 Soy tu asistente de smartphones. ¿Qué modelo buscas hoy?`, 
      sender: 'bot',
      options: ['Ver opciones', 'Ayuda']
    }]);
  }, [user?.name]);

  // Auto scroll al final de los mensajes
  useEffect(() => {
    scrollToBottom({ behavior: 'auto' });
  }, [messages, scrollToBottom]);

  // Enfocar el input al abrir
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }

    return () => {
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.95 }}
      transition={{ type: 'spring', damping: 25, stiffness: 300 }}
      className="w-full h-full flex flex-col bg-white rounded-xl shadow-xl overflow-hidden relative"
    >
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 rounded-t-xl flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-400 rounded-full flex items-center justify-center">
            <FiShoppingCart className="text-white" />
          </div>
          <div>
            <h4 className="font-bold">Asistente de Smartphones</h4>
            <p className="text-xs text-blue-100">En línea</p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="text-white hover:text-blue-200 ml-2"
        >
          <FiX />
        </button>
      </div>
      
      {/* Botones de desplazamiento */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: showScrollButtons ? 1 : 0 }}
        transition={{ duration: 0.2 }}
        className="absolute right-4 top-16 flex flex-col gap-2 z-10"
      >
        <button
          onClick={scrollToTop}
          className="bg-white/90 hover:bg-white text-gray-700 p-2 rounded-full shadow-md flex items-center justify-center transition-all hover:shadow-lg"
          title="Ir al inicio"
        >
          <FiChevronUp size={16} />
        </button>
        <button
          onClick={() => scrollToBottom({ behavior: 'smooth', force: true })}
          className="bg-white/90 hover:bg-white text-gray-700 p-2 rounded-full shadow-md flex items-center justify-center transition-all hover:shadow-lg"
          title="Ir al final"
        >
          <FiChevronDown size={16} />
        </button>
      </motion.div>

      {/* Cuerpo del chat */}
      <div 
        ref={chatRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100"
        onMouseEnter={() => setShowScrollButtons(true)}
        onMouseLeave={() => {
          if (chatRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = chatRef.current;
            const isAtBottom = scrollHeight - (scrollTop + clientHeight) < 20;
            const isAtTop = scrollTop < 20;
            setShowScrollButtons(!isAtTop || !isAtBottom);
          }
        }}
      >
        {(messages || []).map((msg, index) => (
          <div key={`msg-${index}`} className={`flex ${msg?.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`rounded-xl p-3 max-w-[85%] ${
                msg?.sender === 'user'
                  ? 'bg-blue-600 text-white rounded-br-none'
                  : msg?.sender === 'system'
                  ? 'bg-green-100 text-green-800 rounded-bl-none'
                  : 'bg-white text-gray-800 rounded-bl-none shadow-sm'
              }`}
            >
              {msg.isHTML ? (
                <p dangerouslySetInnerHTML={{ __html: msg.text }} />
              ) : (
                <p className="whitespace-pre-line">{msg.text}</p>
              )}
              
              {/* Opciones rápidas */}
              {(msg?.options || []).map((option, i) => (
                <button
                  key={`opt-${i}`}
                  onClick={() => {
                    setMessage(option);
                    setTimeout(() => handleSendMessage({ preventDefault: () => {} }), 100);
                  }}
                  className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full hover:bg-blue-200 transition-colors mr-2 mt-2"
                >
                  {option}
                </button>
              ))}
            </motion.div>
          </div>
        ))}
        
        {/* Indicador de que el bot está escribiendo */}
        {isTyping && (
          <div className="flex justify-start">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white text-gray-800 rounded-xl rounded-bl-none p-3 shadow-sm max-w-[50%]"
            >
              <div className="flex space-x-2 items-center">
                {[0, 1, 2].map((i) => (
                  <motion.div 
                    key={`typing-${i}`}
                    className="w-2 h-2 bg-gray-400 rounded-full"
                    animate={{ y: [0, -5, 0] }}
                    transition={{ 
                      repeat: Infinity,
                      duration: 0.8,
                      delay: i * 0.2
                    }}
                  />
                ))}
                <span className="ml-2 text-xs text-gray-500">escribiendo...</span>
              </div>
            </motion.div>
          </div>
        )}
      </div>
      
      {/* Input para enviar mensajes */}
      <div className="p-4 border-t border-gray-200 bg-white relative">
        <button
          onClick={clearChat}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-blue-600 transition-colors"
          title="Limpiar chat"
        >
          <FiRefreshCw size={18} />
        </button>
        
        <form onSubmit={handleSendMessage} className="relative ml-8">
          <input
            ref={inputRef}
            type="text"
            value={message}
            onChange={(e) => setMessage(e?.target?.value || '')}
            placeholder="Escribe tu mensaje..."
            className="w-full px-4 py-3 border border-gray-300 rounded-full text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
          />
          <button 
            type="submit" 
            disabled={!message.trim()}
            className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-2 rounded-full ${
              message.trim() ? 'text-blue-600 hover:text-blue-800' : 'text-gray-400'
            }`}
          >
            <FiArrowRight />
          </button>
        </form>
      </div>
    </motion.div>
  );
};

Chatbot.propTypes = {
  user: PropTypes.shape({
    name: PropTypes.string
  }),
  onClose: PropTypes.func,
  onMessageSent: PropTypes.func
};

export default Chatbot;