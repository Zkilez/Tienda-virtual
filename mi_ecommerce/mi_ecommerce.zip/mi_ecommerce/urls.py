from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from productos.views import inicio  # Usamos solo esta vista
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('', inicio, name='inicio'),
    path('admin/', admin.site.urls),  # Cambié a admin.site.urls estándar
    path('productos/', include('productos.urls')),
    path('api/users/', include('usuarios.urls')),
    path('chatbot/', include('chatbot.urls')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)