from django.contrib import admin

admin.site.site_header = "Administración de Mi Tienda"
admin.site.site_title = "Panel de Administración"
admin.site.index_title = "Gestión de Productos y Pedidos"
